package database;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.core.Response;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;


@Path("/")
public class ExampleResource 
{
	private final myDAO mydao;
	
	public ExampleResource(myDAO mydao)
	{
		this.mydao = mydao;
	}
	
	@GET
	@Path("/findIdByTitle/{title}")
	public Response get(@PathParam("title") String title)
	{
		return Response.ok(mydao.findIdByTitle(title)).build();
	}

	@POST
	@Path("/insert/{series_name}")
	public Response post(@PathParam("series_name") String series_name, ExampleObject object)
	{
		if(object!=null)
		{
			mydao.insert(
					object.getAniList_id(),
					object.getTVDB_id(),
					object.getTitle(),
					object.getContinuous(),
					object.getNext_episode_number(),
					object.getUTC_air_date_of_next_episode(),
					object.getStatus()
			);
			return Response.ok().build();
		}
		return Response.serverError().build();
	}


	
	
	
	
}
