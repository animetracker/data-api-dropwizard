package database;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExampleObject
{
    @JsonProperty
    private final int AniList_id, TVDB_id, continuous,  next_episode_number;
    @JsonProperty
    private final String title, UTC_air_date_of_next_episode, status;

    public ExampleObject()
    {
        title = "hallo";
        continuous = 0;
        AniList_id = 69;
        TVDB_id = 420;
        next_episode_number = 7;
        status = "RELEASING";
        UTC_air_date_of_next_episode  = "20/7/2020 18:00";
    }

    public int getAniList_id(){return AniList_id;}

    public int getTVDB_id(){return TVDB_id;}

    public int getContinuous(){return continuous;}

    public int getNext_episode_number(){return next_episode_number;}

    public String getTitle(){return title;}

    public String getUTC_air_date_of_next_episode(){return UTC_air_date_of_next_episode;}

    public String getStatus(){return status;}
}
