package database;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

public interface myDAO
{
    @SqlUpdate("insert into anime_list (AniList_id, TVDB_id, title, continuous, next_episode_number, UTC_air_date_of_next_episode, status) values (:AniList_id, :TVDB_id, :title, :continuous, :next_episode_number, :UTC_air_date_of_next_episode, :status)")
    void insert(@Bind("AniList_id") int AniList_id, @Bind("TVDB_id") int TVDB_id, @Bind("title") String title, @Bind("continuous") int continuous, @Bind("next_episode_number") int next_episode_number, @Bind("UTC_air_date_of_next_episode") String UTC_air_date_of_next_episode, @Bind("status") String status);

    @SqlQuery("select id from anime_list where title = :title")
    int findIdByTitle(@Bind("title") String title);
}
