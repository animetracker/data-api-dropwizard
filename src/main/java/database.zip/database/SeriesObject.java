package database;

import lombok.Getter;
import org.json.JSONObject;

public class SeriesObject
{
    // What is passed in
    private final String series_name;

    // Objects part of JSON
    private int AniList_id;
    private int TVDB_id;
    private String title;
    private int continuous;
    private int next_episode_number;
    private String UTC_air_date_of_next_episode;
    private String status;

    // JSON
    private JSONObject json;

    public SeriesObject(String series_name)
    {
        this.series_name = series_name;
        setObjects();
        constructJSON();
    }

    public void setObjects()
    {
        title = "hallo";
        continuous = 0;
        AniList_id = 69;
        TVDB_id = 420;
        next_episode_number = 7;
        status = "RELEASING";
        UTC_air_date_of_next_episode  = "20/7/2020 18:00";
    }

    private void constructJSON()
    {
        json = new JSONObject();
        json.put("title", title);
        json.put("continuous", continuous);
        json.put("AniList_id", AniList_id);
        json.put("TVDB_id", TVDB_id);
        json.put("next_episode_number", next_episode_number);
        json.put("status", status);
        json.put("UTC_air_date_of_next_episode", UTC_air_date_of_next_episode);
    }

    public JSONObject getJSON()
    {
        return json;
    }

}
