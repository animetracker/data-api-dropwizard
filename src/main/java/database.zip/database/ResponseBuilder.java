package database;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.json.JSONObject;

import javax.ws.rs.core.Response;

public class ResponseBuilder {

    private static final ObjectWriter objectWriter = new ObjectMapper()
            .writer()
            .without(SerializationFeature.INDENT_OUTPUT);

    private final JSONObject response = new JSONObject();

    public ResponseBuilder(boolean err) {
        response.put("error", err);
    }

    public ResponseBuilder() {}

    public ResponseBuilder put(String key, Object value) {
        try {
            response.put(key, new JSONObject(objectWriter.writeValueAsString(value)));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return this;
    }

    public ResponseBuilder put(String key, int value) {
        response.put(key, value);
        return this;
    }

    public ResponseBuilder put(String key, boolean value) {
        response.put(key, value);
        return this;
    }

    public ResponseBuilder put(String key, String value) {
        response.put(key, value);
        return this;
    }

    public Response build() {
        return Response.ok(response.toString()).build();
    }
}